<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <?php include "imports.php"; ?>
  <title>Single</title>
</head>
<body>
  <?php include "headerLoggedOut.php" ?>

  <div class="container">
    <div class="row">
      <div class="col-7">
        <img src="https://via.placeholder.com/600x400.png?text=Product+1" class="img-fluid" alt="Responsive image">
      </div>
      <div class="col-5">
        <p class="h2 font-weight-bold">Product 1</p>
        <p class="h4 font-weight-normal">LKR 100</p>
        <hr>
        <p class="h6">Item Code - 4652</p>
        <p class="h6">Category - Beverages</p>
        <form class="form-inline">
          <label class="my-1 mr-2" for="inlineFormCustomSelectPref">Quantity</label>
          <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref">
            <option selected>Choose...</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
          <button type="submit" class="btn btn-warning my-1">Submit</button>
        </form>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <p class="h2 text-center">Related Products</p>
        <div class="card-deck">
          <div class="card shadow">
            <img class="card-img-top" src="https://via.placeholder.com/300x200.png?text=Product+1" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Product 1</h5>
              <p class="card-text mt-n3">LKR 100</p>
              <p class="card-text text-center"><button type="button" class="btn btn-outline-success">Add To Cart</button></p>
            </div>
          </div>
          <div class="card shadow">
            <img class="card-img-top" src="https://via.placeholder.com/300x200.png?text=Product+2" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Product 2</h5>
              <p class="card-text mt-n3">LKR 200</p>
              <p class="card-text text-center"><button type="button" class="btn btn-outline-success">Add To Cart</button></p>
            </div>
          </div>
          <div class="card shadow">
            <img class="card-img-top" src="https://via.placeholder.com/300x200.png?text=Product+3" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Product 3</h5>
              <p class="card-text mt-n3">LKR 300</p>
              <p class="card-text text-center"><button type="button" class="btn btn-outline-success">Add To Cart</button></p>
            </div>
          </div>
          <div class="card shadow">
            <img class="card-img-top" src="https://via.placeholder.com/300x200.png?text=Product+4" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Product 4</h5>
              <p class="card-text mt-n3">LKR 400</p>
              <p class="card-text text-center"><button type="button" class="btn btn-outline-success">Add To Cart</button></p>
            </div>
          </div>
          <div class="card shadow">
            <img class="card-img-top" src="https://via.placeholder.com/300x200.png?text=Product+5" alt="Card image cap">
            <div class="card-body">
              <h5 class="card-title">Product 5</h5>
              <p class="card-text mt-n3">LKR 500</p>
              <p class="card-text text-center"><button type="button" class="btn btn-outline-success">Add To Cart</button></p>
            </div>
          </div>
        </div>
      </div>


    </div>
  </div>

</body>
</html>
